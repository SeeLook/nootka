The debian folder was taken from debian-multimedia.org and was done originally by Christian Marillat
I (Seelook) put it in nootka tree to ease packager job

